<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>NLP Chatbot | Login</title>
  <link rel="icon" href="assets/images/logo.png" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <script src="assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/dist/js/sweetalert.min.js"></script>
</head>

<body>

  <div class="container">
    <div class="row" style="background-color: #f5f5f5">
      <div class="col-sm-12 text-center">
        <a href="index.php"><img src="assets/images/logo.png" style="height: 200px"></a>
      </div>
    </div>

    <div class="row" style="background-color: #ececec">

      <div class="col-sm-offset-4 col-sm-4">
        <form action="" method="POST">
          <div class="panel panel-primary" style="text-align: center; margin-top: 10%; border: 10px solid #fff">
            <div class="panel-body">
              <div class="form-group">
                <div class="input-group">
                  <div class="input-group-addon">
                    <span class="glyphicon glyphicon-user"></span>
                  </div>
                  <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group">
                  <div class="input-group-addon">
                    <span class="glyphicon glyphicon-lock"></span>
                  </div>
                  <input type="password" name="password" class="form-control" maxlength="10" placeholder="Enter Password" required>
                </div>
              </div>
              <div class="form-group">
                <div class="input-group">
                  <div class="input-group-addon">
                    <span class="glyphicon glyphicon-user"></span>
                  </div>
                  <select name="uType" class="form-control" required>
                    <option value="" selected disabled>Select User Type</option>
                    <option value="student">Student</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
              </div><br><br>
              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block" name="Submit"><span class="glyphicon glyphicon-log-in"></span>&nbsp; Login
                </button>
              </div>
            </div>
        </form>
        <div class="panel-footer">


          <?php

          include "config/db.php";
          if (isset($_GET['error'])) {
            echo "<font color='red'><span class='glyphicon glyphicon-remove-sign '></span> " . @$_GET['error'];
          }
          if (isset($_GET['msg'])) {
            echo "<font color='greem'><span class='glyphicon glyphicon-ok '></span> " . @$_GET['msg'];
          }
          if (isset($_POST['Submit'])) {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $uType = $_POST['uType'];


            $result = mysqli_query($con, "SELECT * from $uType where email='$email' and password='$password'");
            $count = mysqli_num_rows($result);
            $user = mysqli_fetch_array($result);


            if ($count > 0) {
                $_SESSION['IS_LOGIN'] = "true";
                $_SESSION['USER_ID'] = $user[0];
                $_SESSION['USER_NAME'] = $user['name'];
                $_SESSION['USER_TYPE'] = $uType;
                echo "<script> window.location.href='dashboard'; </script>";
              
            } else {
              echo "<script> swal('', 'Email Or Password not correct', 'error'); </script>";
            }
          }
          ?>
        </div>
        <a data-toggle="modal" href='#StudentModal' class="btn btn-sm btn-primary">Register as Student</a>
      </div>
    </div>
  </div>
  </div>
</body>

</html>



<div class="modal fade" id="StudentModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Student Registration</h4>
      </div>
      <div class="modal-body">
        <form action="" method="POST" enctype="multipart/form-data">
          <div class="row">
            <div class="col-sm-12">
              <label>Student Name</label>
              <input type="text" name="name" class="form-control" placeholder="Enter Student Name" required>
            </div>
            <div class="col-sm-12">
              <label>Email</label>
              <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
            </div>
          </div><br>
          <div class="row">
            <div class="col-sm-12">
              <label>Contact No</label>
              <input type="text" name="cellNo" class="form-control" placeholder="Enter Contact No" required>
            </div><br>
            <div class="col-sm-12">
              <label>Password</label>
              <input type="password" name="password" placeholder="Enter Password" class="form-control" required>
            </div><br>
          </div><br>
          <button type="submit" class="btn btn-sm btn-primary pull-right" name="RegisterAsStudent"> Register As Student
          </button><br><br>
        </form>
      </div>
    </div>
  </div>
</div>


<?php
if (isset($_POST['RegisterAsStudent'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $cellNo = $_POST['cellNo'];
  $password = $_POST['password'];

  $query = "INSERT INTO student SET name ='$name', email = '$email', phone = '$cellNo', password = '$password'";

  $result = mysqli_query($con, $query);
  if ($result) {
    echo "<script> swal('', 'Registered Successfully', 'success'); </script>";
  } else {
    echo "Error" . mysqli_error($con);
  }
}



?>