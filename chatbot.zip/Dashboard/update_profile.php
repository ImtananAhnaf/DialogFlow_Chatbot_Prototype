<?php
$ID = $_SESSION['USER_ID'];
$Student = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM student WHERE StudentID = '$ID'"));
?>


<div class="panel panel-primary">
      <div class="panel-heading">
            <h3 class="panel-title">Update Profile</h3>
      </div>
      <div class="panel-body">
      <form action="" method="POST" enctype="multipart/form-data">
          <div class="row">
            <div class="col-sm-12">
              <label>Student Name</label>
              <input type="text" name="name" class="form-control" value="<?=$Student['name']?>" required>
            </div>
            <div class="col-sm-12">
              <label>Email</label>
              <input type="email" name="email" class="form-control" value="<?=$Student['email']?>" required>
            </div>
          </div><br>
          <div class="row">
            <div class="col-sm-12">
              <label>Contact No</label>
              <input type="text" name="cellNo" class="form-control" value="<?=$Student['phone']?>" required>
            </div><br>
            <div class="col-sm-12">
              <label>Password</label>
              <input type="text" name="password" value="<?=$Student['password']?>" class="form-control" required>
            </div><br>
          </div><br>
          <button type="submit" class="btn btn-sm btn-primary pull-right" name="Update"> Update
          </button><br><br>
        </form>
      </div>
</div>

<?php
if (isset($_POST['Update'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $cellNo = $_POST['cellNo'];
  $password = $_POST['password'];

  $query = "UPDATE student SET name ='$name', email = '$email', phone = '$cellNo', password = '$password' WHERE StudentID = '$ID'";

  $result = mysqli_query($con, $query);
  if ($result) {
    echo "<script> alert('Profile Updated Successfully');
            window.location.href='index.php?page=update_profile'; </script>";
  } else {
    echo "Error" . mysqli_error($con);
  }
}



?>