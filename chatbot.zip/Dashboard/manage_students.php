<div class="row" style="margin-top: -12px !important">
    <div style="background: #201D1D; padding-right: 15px; height: 45px; line-height: 45px;">
        <div class="col-sm-4">
            <button type="button" class="btn btn-sm hvr-bounce-to-right" data-toggle="modal" data-target="#StdModal">Add New Student</button>
        </div>
        <div class="col-sm-4">
            <?php
            if (isset($_GET['msg'])) { ?>
                <div class="alert alert-danger" style="padding: 0; text-align: center;">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong><?= $_GET['msg'] ?></strong>
                </div>
            <?php } ?>
        </div>
        <div class="col-sm-4"><span class="title pull-right">Student's Management</span></div>
    </div>
    <div class="modal fade" id="StdModal" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add New Student</h4>
                </div>
                <div class="modal-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Student Name</label>
                                <input type="hidden" name="ID" value="0" id="S_ID">
                                <input type="text" name="name" class="form-control" placeholder="Enter Student Name" id="sname">
                            </div>
                            <div class="col-sm-12">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter Email" id="semail">
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-sm-12">
                                <label>Contact No</label>
                                <input type="text" name="cellNo" class="form-control" placeholder="Enter Contact No" id="scell">
                            </div>
                            <div class="col-sm-12">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" id="spass">
                            </div><br>
                        </div>


                </div>
                <div class="modal-footer">
                    <center>
                        <input type="submit" name="addStudent" value="Add Student" class="btn btn-success" id="sbtn">
                    </center>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="col-sm-12" style="margin-top: 5%">
        <table id="table" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student Name</th>
                    <th>Email</th>
                    <th>Contact No</th>
                    <th>Registered On</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                $result = mysqli_query($con, "SELECT * FROM student");
                while ($row = mysqli_fetch_array($result)) {
                    echo "<tr>
                <td>$i</td>
                <td>$row[name]</td>
                    <td>$row[email]</td>
                    <td>$row[phone]</td>
                    <td>$row[created_at]</td>
                    <td>
                    <a href='index.php?page=manage_students&Delete=Yes&ID=$row[StudentID]' class='btn btn-danger btn-xs'><span class='glyphicon glyphicon-trash'></span></a>
                    </td></tr>";
                    $i++;
                } ?>
            </tbody>
        </table>
    </div>
</div>
<?php
if (isset($_POST['addStudent'])) {
    $ID = $_POST['ID'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $cellNo = $_POST['cellNo'];
    $password = $_POST['password'];

    $query = "INSERT INTO student SET name ='$name', email = '$email', phone = '$cellNo', password = '$password'";
        $msg = "Record Inserted";

    $result = mysqli_query($con, $query);
    if ($result) {
        echo "<script>
window.location='index.php?page=manage_students&msg=$msg';
</script>";
    } else {
        echo "Error" . mysqli_error($con);
    }
}


if (isset($_GET['Delete'])) {
    $ID = $_GET['ID'];
    $result = mysqli_query($con, "DELETE FROM student WHERE StudentID = '$ID'");
    if ($result) {
        echo "<script>
window.location='index.php?page=manage_students&msg=Record Deleted';
</script>";
    }
}
?>
