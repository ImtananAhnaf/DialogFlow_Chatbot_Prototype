
    <div class="container">
        <div class="chat-container">
            <h2 class="text-center">Restaurant Chatbot</h2>
            <div class="chat-box" id="chat-box">
                <!-- Chat messages will appear here -->
                <div class="message bot">
                    <p>Hello! How can I assist you today?</p>
                </div>
            </div>
            <div class="input-group">
                <input type="text" id="user-input" class="form-control" placeholder="Type your message...">
                <span class="input-group-btn">
                    <button class="btn btn-primary" id="send-btn">Send</button>
                </span>
            </div>
        </div>
    </div>

