<?php 
	include '../config/db.php';

	function Load_Page($page){
		global $con;
           switch($page)
                 {
                  case $page:
                      include $page.'.php';
                    break; 

                    default :
                    include ('default.php');
                }
} ?>